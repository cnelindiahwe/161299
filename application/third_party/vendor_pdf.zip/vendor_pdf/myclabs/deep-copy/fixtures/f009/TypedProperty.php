<?php declare(strict_types=1);

namespace DeepCopy\f009;

class TypedProperty
{
    public int $foo;
}
