<?php

namespace Mpdf\Tag;

class Dd extends BlockTag
{


}
